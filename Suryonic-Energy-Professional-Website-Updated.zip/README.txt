SURYONIC ENERGY WEBSITE
Upload index.html to Cloudflare static hosting.
Before publishing, replace ADD YOUR MOBILE NUMBER and ADD YOUR BUSINESS EMAIL in index.html.
The site includes services, PM Surya Ghar assistance, service area, enquiry form and SEO metadata.
